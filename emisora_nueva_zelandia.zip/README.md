# Emisora Nueva Zelandia

## Ejecutar
Requiere Node.js 18+.

```bash
npm install
npm start
```

Abre `http://localhost:3000` para el formulario y `http://localhost:3000/admin-server.html` para moderar solicitudes.

## QR
El QR se genera automáticamente con la URL actual. Después de publicar el sitio en una URL pública HTTPS, abre la página pública y descarga el PNG desde el botón del QR.

## Importante
`requests.json` es almacenamiento sencillo para un evento escolar. Para tráfico muy alto, cambia el almacenamiento por una base de datos gestionada. La moderación incluida es básica y debe complementarse con revisión humana.
